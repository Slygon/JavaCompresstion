package compression_algorithms;

public abstract class Compressor implements Compressible {
	
}
