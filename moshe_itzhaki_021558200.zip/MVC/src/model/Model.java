package model;

public interface Model {

}
