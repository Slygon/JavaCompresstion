package model;

public abstract class Compressor implements Compressible {
	
}
