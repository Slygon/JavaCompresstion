package model;


public class WordDictionary extends Compressor {

	@Override
	public String compress(String oStream) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String decompress(Object oStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
